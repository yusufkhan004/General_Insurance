import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
