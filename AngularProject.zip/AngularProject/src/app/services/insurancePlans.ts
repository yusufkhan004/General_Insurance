export class InsurancePlan{


    constructor(
        planType:String,
        planDuration:number
    ){}
}