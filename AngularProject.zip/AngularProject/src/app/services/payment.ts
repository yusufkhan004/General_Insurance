export class Payment {

    constructor(
        paymentDate:Date,
        paymentAmount: Number,
        paymentDescription: String,
        
    ){
        
    }
}
