export class Claims{
    constructor(
        policyno:number,
        mobileno:number,
        reason:string
    ){}
}