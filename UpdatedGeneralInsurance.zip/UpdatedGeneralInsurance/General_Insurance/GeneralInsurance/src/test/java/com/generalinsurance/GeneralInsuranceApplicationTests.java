package com.generalinsurance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeneralInsuranceApplicationTests {

	@Test
	void contextLoads() {
	}

}
